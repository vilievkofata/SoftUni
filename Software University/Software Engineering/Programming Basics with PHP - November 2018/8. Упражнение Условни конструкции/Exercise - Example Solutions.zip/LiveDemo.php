<?php

$a=5;
$b=10;
echo $a;